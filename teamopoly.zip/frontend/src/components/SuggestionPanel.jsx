export default function SuggestionPanel({ suggestions }){
  return (
    <div className="bg-white rounded-2xl shadow p-4">
      <h2 className="font-semibold mb-2">Suggestions</h2>
      <ul className="list-disc pl-6 text-sm">
        {(suggestions||[]).map((s, i)=> <li key={i}>{s}</li>)}
      </ul>
    </div>
  )
}
