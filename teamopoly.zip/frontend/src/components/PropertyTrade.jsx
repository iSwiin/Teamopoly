import { useState } from 'react'

export default function PropertyTrade({ tiles, contributors, onTrade }){
  const users = Object.keys(contributors||{})
  const properties = (tiles||[]).filter(t=>t.type==='property')
  const [prop, setProp] = useState(properties[0]?.name)
  const [from, setFrom] = useState(users[0])
  const [to, setTo] = useState(users[1]||users[0])

  return (
    <div className="bg-white rounded-2xl shadow p-4">
      <h2 className="font-semibold mb-2">Trade a Task (Property)</h2>
      <div className="grid grid-cols-3 gap-3 text-sm">
        <select value={prop} onChange={e=>setProp(e.target.value)} className="border rounded p-2">
          {properties.map(p=> <option key={p.name}>{p.name}</option>)}
        </select>
        <select value={from} onChange={e=>setFrom(e.target.value)} className="border rounded p-2">
          {users.map(u=> <option key={u}>{u}</option>)}
        </select>
        <select value={to} onChange={e=>setTo(e.target.value)} className="border rounded p-2">
          {users.map(u=> <option key={u}>{u}</option>)}
        </select>
      </div>
      <button onClick={()=> onTrade?.(prop, from, to)} className="mt-3 px-3 py-2 rounded bg-emerald-600 text-white">Propose Trade</button>
    </div>
  )
}
