export default function ContributionBars({ contributors, scores }){
  const areas = ["writing","coding","reviewing","planning","testing"]
  const users = Object.keys(contributors||{})
  return (
    <div className="bg-white rounded-2xl shadow p-4">
      <h2 className="font-semibold mb-2">Team Areas</h2>
      <div className="grid gap-4">
        {users.map(u=>{
          const c = contributors[u]
          return (
            <div key={u} className="">
              <div className="flex items-center justify-between mb-1">
                <div className="font-medium">@{u}</div>
                <div className="text-sm text-slate-500">Score: {scores?.[u]??'-'}</div>
              </div>
              <div className="grid grid-cols-5 gap-2">
                {areas.map(a=> (
                  <div key={a} className="">
                    <div className="text-xs text-slate-500 mb-1">{a}</div>
                    <div className="h-3 bg-slate-100 rounded">
                      <div className="h-3 rounded bg-slate-400" style={{width: `${Math.min(100, (c?.[a]||0)*10)}%`}} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
