export default function Board({ tiles, owners }){
  return (
    <div className="bg-white rounded-2xl shadow p-4">
      <h2 className="font-semibold mb-3">Board</h2>
      <div className="grid grid-cols-4 gap-2">
        {(tiles||[]).map((t,i)=> (
          <div key={i} className={`rounded-xl border p-3 ${t.type==='property' ? 'bg-amber-50' : 'bg-slate-50'}`}>
            <div className="text-sm font-medium">{t.name}</div>
            <div className="text-xs text-slate-500">{t.type}</div>
            {t.type==='property' && owners?.[t.name] && (
              <div className="mt-1 text-xs">Owner: <b>@{owners[t.name]}</b></div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
