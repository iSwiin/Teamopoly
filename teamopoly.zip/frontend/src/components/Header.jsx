export default function Header(){
  return (
    <header className="p-4 flex items-center justify-between bg-white shadow">
      <h1 className="text-2xl font-bold">Teamopoly</h1>
      <p className="text-sm text-slate-500">Fairness dashboard • Monopoly skin</p>
    </header>
  )
}
