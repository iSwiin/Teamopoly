export default function WeightSliders({ weights, setWeights, onRecompute }){
  const entries = Object.entries(weights)
  return (
    <div className="bg-white rounded-2xl shadow p-4">
      <h2 className="font-semibold mb-3">Team Agreement Weights</h2>
      <div className="grid grid-cols-2 gap-3">
        {entries.map(([k,v])=> (
          <label key={k} className="text-sm">
            <div className="flex justify-between"><span>{k}</span><span className="text-slate-500">{v}</span></div>
            <input type="range" min="-3" max="5" value={v} className="w-full"
              onChange={e=> setWeights(w=> ({...w, [k]: parseInt(e.target.value)}))} />
          </label>
        ))}
      </div>
      <button onClick={onRecompute} className="mt-3 px-3 py-2 rounded bg-black text-white">Recompute Scores</button>
    </div>
  )
}
