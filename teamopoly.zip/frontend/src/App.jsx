import { useEffect, useState } from 'react'
import Header from './components/Header'
import ContributionBars from './components/ContributionBars'
import SuggestionPanel from './components/SuggestionPanel'
import WeightSliders from './components/WeightSliders'
import PropertyTrade from './components/PropertyTrade'
import Board from './components/Board'
import { fetchSummary, fetchScores } from './api'

const DEFAULT_WEIGHTS = {
  prs_merged:3, reviews_given:3, issues_closed:2, review_response_hours:2,
  coverage_delta:1, small_prs:1, mega_prs:-1,
  writing:2, coding:2, reviewing:2, planning:1, testing:2
}

export default function App(){
  const [owner, setOwner] = useState('vercel') // change for demo
  const [repo, setRepo] = useState('next.js')  // public repo to demo
  const [contributors, setContributors] = useState(null)
  const [tiles, setTiles] = useState([])
  const [weights, setWeights] = useState(DEFAULT_WEIGHTS)
  const [scores, setScores] = useState({})
  const [suggestions, setSuggestions] = useState([])
  const [owners, setOwners] = useState({}) // property owners

  useEffect(()=>{ (async()=>{
    const s = await fetchSummary(owner, repo)
    setContributors(s.contributors)
    setTiles(s.tiles)
    setSuggestions(s.suggestions)
    // naive owners: assign first N properties round-robin to users
    const users = Object.keys(s.contributors||{})
    const props = (s.tiles||[]).filter(t=>t.type==='property')
    const O = {}
    props.forEach((p, i)=> O[p.name] = users[i % (users.length||1)] || 'unknown')
    setOwners(O)
  })() }, [owner, repo])

  async function recompute(){
    const sc = await fetchScores(contributors, weights)
    setScores(sc.scores)
  }

  function onTrade(prop, from, to){
    setOwners(o=> ({...o, [prop]: to}))
  }

  return (
    <div className="min-h-screen">
      <Header />
      <div className="max-w-6xl mx-auto p-4 grid md:grid-cols-3 gap-4">
        <div className="md:col-span-3 bg-white rounded-2xl shadow p-4 flex gap-2 items-end">
          <div>
            <label className="block text-sm">Owner</label>
            <input value={owner} onChange={e=>setOwner(e.target.value)} className="border rounded p-2"/>
          </div>
          <div>
            <label className="block text-sm">Repo</label>
            <input value={repo} onChange={e=>setRepo(e.target.value)} className="border rounded p-2"/>
          </div>
          <button onClick={()=> window.location.reload()} className="ml-auto px-3 py-2 rounded bg-blue-600 text-white">Load</button>
        </div>

        <div className="md:col-span-2 grid gap-4">
          <ContributionBars contributors={contributors} scores={scores} />
          <WeightSliders weights={weights} setWeights={setWeights} onRecompute={recompute}/>
          <Board tiles={tiles} owners={owners} />
        </div>
        <div className="grid gap-4">
          <SuggestionPanel suggestions={suggestions} />
          <PropertyTrade tiles={tiles} contributors={contributors} onTrade={onTrade} />
        </div>
      </div>
    </div>
  )
}
