const API = import.meta.env.VITE_API || "http://localhost:8000";
export const fetchSummary = async (owner, repo) => {
  const res = await fetch(`${API}/api/summary`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ owner, repo })
  });
  return res.json();
};

export const fetchScores = async (contributors, weights) => {
  const res = await fetch(`${API}/api/score`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ contributors, weights })
  });
  return res.json();
};
