import httpx
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Dict

from metrics import fetch_repo_summary
from monopoly import derive_tiles, suggest_rebalancing

app = FastAPI(title="Teamopoly API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class RepoReq(BaseModel):
    owner: str
    repo: str

@app.get("/health")
async def health():
    return {"ok": True}

@app.post("/api/summary")
async def summary(body: RepoReq):
    data = await fetch_repo_summary(body.owner, body.repo)
    # Try to fetch tree for tiles
    async with httpx.AsyncClient(timeout=20) as client:
        tree = (await client.get(f"https://api.github.com/repos/{body.owner}/{body.repo}/git/trees/HEAD?recursive=1")).json()
        paths = [item.get("path", "") for item in (tree.get("tree") or [])]
    tiles = derive_tiles(paths)
    suggestions = suggest_rebalancing(data["contributors"]) if data.get("contributors") else ["No contributors detected"]
    return {"repo": data["repo"], "contributors": data["contributors"], "tiles": tiles, "suggestions": suggestions}

class Weights(BaseModel):
    prs_merged: int = 3
    reviews_given: int = 3
    issues_closed: int = 2
    review_response_hours: int = 2
    coverage_delta: int = 1
    small_prs: int = 1
    mega_prs: int = -1
    writing: int = 2
    coding: int = 2
    reviewing: int = 2
    planning: int = 1
    testing: int = 2

@app.post("/api/score")
async def score(body: Dict[str, Dict]):
    """Body: { "contributors": {login: metrics...}, "weights": {...} }"""
    contributors: Dict[str, Dict] = body.get("contributors", {})
    w = Weights(**body.get("weights", {}))
    # Normalize per metric (min-max) to keep fairness
    keys = [k for k in contributors.keys()]
    metrics = [
        "prs_merged","reviews_given","issues_closed","small_prs","mega_prs",
        "coverage_delta","review_response_hours","writing","coding","reviewing","planning","testing"
    ]
    mins = {m: float('inf') for m in metrics}
    maxs = {m: float('-inf') for m in metrics}
    for u in keys:
        for m in metrics:
            v = float(contributors[u].get(m,0))
            if v < mins[m]: mins[m] = v
            if v > maxs[m]: maxs[m] = v

    def norm(m, v):
        lo, hi = mins[m], maxs[m]
        if hi == lo: return 0.0
        return (float(v) - lo) / (hi - lo)

    scores = {}
    for u in keys:
        c = contributors[u]
        s = (
            3*norm("prs_merged", c.get("prs_merged",0)) +
            3*norm("reviews_given", c.get("reviews_given",0)) +
            2*norm("issues_closed", c.get("issues_closed",0)) +
            2*(1-norm("review_response_hours", c.get("review_response_hours",0))) +
            1*norm("coverage_delta", c.get("coverage_delta",0)) +
            1*norm("small_prs", c.get("small_prs",0)) -
            1*norm("mega_prs", c.get("mega_prs",0)) +
            2*norm("writing", c.get("writing",0)) +
            2*norm("coding", c.get("coding",0)) +
            2*norm("reviewing", c.get("reviewing",0)) +
            1*norm("planning", c.get("planning",0)) +
            2*norm("testing", c.get("testing",0))
        )
        scores[u] = round(float(s), 3)

    return {"scores": scores}
