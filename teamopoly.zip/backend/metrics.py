from typing import Dict, List
import httpx
import os

GITHUB_API = "https://api.github.com"
TOKEN = os.getenv("GITHUB_TOKEN", "")

HEADERS = {"Accept":"application/vnd.github+json"} | ({"Authorization": f"Bearer {TOKEN}"} if TOKEN else {})

# Simple, conservative categorization by filepath keywords
AREAS = {
  "writing": ["/docs", ".md"],
  "coding": ["/src", ".py", ".js", ".ts", ".go", ".java", ".php", ".cpp"],
  "reviewing": ["review"],
  "planning": ["/plans", "/design", "/spec"],
  "testing": ["/test", "/tests", ".spec.", ".test."]
}

async def fetch_repo_summary(owner: str, repo: str, since: str | None = None, until: str | None = None) -> Dict:
    # Minimal PR + reviews summary; robust enough for demo
    async with httpx.AsyncClient(timeout=20) as client:
        prs = (await client.get(f"{GITHUB_API}/repos/{owner}/{repo}/pulls", params={"state":"all","per_page":50}, headers=HEADERS)).json()

        # Reviews per PR
        contributions: Dict[str, Dict] = {}
        for pr in prs:
            user = (pr.get("user") or {}).get("login") or "unknown"
            merged = bool(pr.get("merged_at"))
            files = (await client.get(pr["url"]+"/files", headers=HEADERS)).json()

            # Area counters by file
            area_counts = {k:0 for k in AREAS}
            for f in files or []:
                fp = f.get("filename","")
                for area, keys in AREAS.items():
                    if any(k in fp for k in keys):
                        area_counts[area] += 1

            reviews = (await client.get(pr["url"]+"/reviews", headers=HEADERS)).json()
            reviews_given = len(reviews or [])

            d = contributions.setdefault(user, {
                "prs_opened":0, "prs_merged":0, "reviews_given":0,
                "issues_closed":0, "small_prs":0, "mega_prs":0,
                "coverage_delta":0, "review_response_hours":0.0,
                "writing":0, "coding":0, "reviewing":0, "planning":0, "testing":0
            })
            d["prs_opened"] += 1
            if merged: d["prs_merged"] += 1
            d["reviews_given"] += reviews_given
            nfiles = len(files or [])
            if nfiles <= 5: d["small_prs"] += 1
            if nfiles >= 50: d["mega_prs"] += 1
            # Map areas roughly to stats
            for area, v in area_counts.items():
                d[area] += v

        return {"repo": f"{owner}/{repo}", "contributors": contributions}
